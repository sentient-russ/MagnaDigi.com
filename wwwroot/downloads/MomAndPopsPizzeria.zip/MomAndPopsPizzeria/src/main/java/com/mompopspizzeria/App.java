package com.mompopspizzeria;

/**
 * This class is required for creating executable jars and is used as a work-around because JDK 7 and newer do not support javafx
 */
public class App {
    public static void main(String[] args){
        MomPopsPizzeriaMain.main(args);
    }
}
