package com.mompopspizzeria;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class OrderController extends MomPopsPizzeriaMain implements Initializable {


    @FXML
    private final ToggleGroup orderTypeGroup = new ToggleGroup();//do not delete. Used by Gluon

    @FXML
    private Button backBtnOrderScene;
    @FXML
    private Button homeBtnOrderScene;
    @FXML
    private Button cancelBtnOrderScene;
    @FXML
    private Button payBtnOrderScene;
    @FXML
    private Button addPizzaBtn;
    @FXML
    protected void cancelBtnActionOrderScene() {
        Stage stage = (Stage) cancelBtnOrderScene.getScene().getWindow();
        stage.close();
    }
    @FXML
    protected void homeBtnActionOrderScene() {
        Stage stage = (Stage) homeBtnOrderScene.getScene().getWindow();
        stage.close();
    }
    @FXML
    protected void backBtnActionOrderScene() {
        Stage stage = (Stage) backBtnOrderScene.getScene().getWindow();
        stage.close();
    }
    @FXML
    protected void payBtnActionOrderScene() {
        Stage stage = (Stage) payBtnOrderScene.getScene().getWindow();
        stage.close();
    }

    @FXML
    private Label listItemSelectedText;
    @FXML
    private Button updateBtnOrderScene;
    @FXML
    ListView<String> orderSummeryList;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String[] list = {"Medium Pizza Panned Sausage Mushrooms Pineapple Onions $8.25", "Bread Sticks $4.00","Pepesi Small $1.00","Medium Pizza Panned Cheese $6.00"};
        for(String s: list){
            orderSummeryList.getItems().add(s);
        }

    }

    @FXML
    public void addPizzaBtnActionOrderScene() throws IOException {

        try {
            Parent root = FXMLLoader.load(getClass().getResource("pizzaSelection-view.fxml"));
            Stage pizzaSelectionStage = new Stage();
            pizzaSelectionStage.setTitle("Mom and Pop's Pizzeria - Pizza Selection");
            pizzaSelectionStage.setScene(new Scene(root, 1200, 750));
            pizzaSelectionStage.show();



        } catch (Exception e) {
            e.printStackTrace();
            e.getCause();
        }
    }
}

