package com.mompopspizzeria;
/*
 * this object class is used to build the menu crusts ArrayList
 */
public class CrustModel {
	String description;
	double price;
	public CrustModel(String desc, double prc) {
		this.description = desc;
		this.price = prc;
	}
}