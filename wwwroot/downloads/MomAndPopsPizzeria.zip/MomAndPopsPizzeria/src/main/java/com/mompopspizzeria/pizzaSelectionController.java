package com.mompopspizzeria;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class pizzaSelectionController extends MomPopsPizzeriaMain implements Initializable {
    static String smallPizza = "Small Pizza";
    static String mediumPizza = "Medium Pizza";
    static String largePizza = "Large Pizza";
    static String xlargePizza = "Extra Large Pizza";
    static String thin = "Thin Crust";
    static String handTossed = "Hand Tossed";
    static String panned = "Panned";
    static String cheese = "Cheese";
    static String pepperonie = "Pepperonie";
    static String sausage = "Sausage";
    static String ham = "Ham";
    static String greenPeppers = "Green Peppers";
    static String onions = "Onions";
    static String tomatos = "Tomato Slices";
    static String mushrooms = "Mushrooms";
    static String pineapple = "Pineapple";
    static String smallDrink = "Small";
    static String mediumDrink = "Medium";
    static String largeDrink = "Large";
    static String pepsi = "Pepesi";
    static String dietPepsi = "Diet Pepsi";
    static String orange = "Orange";
    static String dietOrange = "Diet Orange";
    static String rootbeer = "Rootbeer";
    static String dietRootbeer = "Diet Rootbeer";
    static String sierraMist = "Sierra Mist";
    static String lemonade = "Lemonade";
    static String breadBites = "Bread Stick Bites";
    static String breadSticks = "Bread Sticks";
    static String cookie = "Big Chocolate Chip Cookie";
    @FXML
    private Label pizzaSelectionValidationText;
    @FXML
    private Label pizzaTotalText;
    @FXML
    private CheckBox extraCheeseToppingChkBox;
    @FXML
    private CheckBox pepperoniToppingChkBox;
    @FXML
    private CheckBox sausageToppingChkBox;
    @FXML
    private CheckBox hamToppingChkBox;
    @FXML
    private CheckBox greenPeppersToppingChkBox;
    @FXML
    private CheckBox onionsToppingChkBox;
    @FXML
    private CheckBox tomatoSlicesToppingChkBox;
    @FXML
    private CheckBox mushroomsToppingChkBox;
    @FXML
    private CheckBox pineappleToppingChkBox;

    @FXML
    private ComboBox<String> pizzaMenuDropdown;


    @FXML
    private ComboBox<String> pizzaCrust;
    @FXML
    private Button backBtnPizzaSelectionScene;
    @FXML
    private Button homeBtnPizzaSelectionScene;
    @FXML
    private Button cancelBtnPizzaSelectionScene;
    @FXML
    private Button addPizzaBtn;


    @FXML
    protected void cancelBtnActionPizzaSelectionScene() {
        Stage stage = (Stage) cancelBtnPizzaSelectionScene.getScene().getWindow();
        stage.close();
    }
    @FXML
    protected void homeBtnActionPizzaSelectionScene() {
        Stage stage = (Stage) homeBtnPizzaSelectionScene.getScene().getWindow();
        stage.close();
    }
    @FXML
    protected void backBtnActionPizzaSelectionScene() {
        Stage stage = (Stage) backBtnPizzaSelectionScene.getScene().getWindow();
        stage.close();
    }
    @FXML
    protected void  addPizzaBtnActionPizzaSelection(){

    }
    @FXML
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //add menu items to dropdown
        ArrayList<PizzaModel> pizzas = dataAccess.getPizzas();
        for(int i = 0; i < pizzas.size(); i++){

            String menuItem = pizzas.get(i).description + " $"+ pizzas.get(i).price;
            pizzaMenuDropdown.getItems().add(menuItem);
        }


    }
}
