package com.mompopspizzeria;

/*
 * this object class is used to build the menu drinks ArrayList
 * @author Russell Geary
 * @version 1.0 10/07/2022
 */
public class DrinkModel {
	String description;
	double price;
	public DrinkModel(String desc, double prc) {
		this.description = desc;
		this.price = prc;
	}
}	