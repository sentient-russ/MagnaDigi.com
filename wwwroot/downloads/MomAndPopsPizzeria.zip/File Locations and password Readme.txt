The actual project structure is located in the "MomAndPopsPizzeria" folder

The main files are located in the "main files consolidated" folder

Of course the .jar is executable and must be extracted before running.  It will create a customer.txt and transactions.txt in the folder that it is run from.
The latest java runtime 19.0.1 is required. https://www.oracle.com/java/technologies/downloads/#jdk19-windows

The employee password is set to: 2345
The manager password is set to: 9876

